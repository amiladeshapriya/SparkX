Welcome to SparkX Cricket Game!
-------------------------------------------------------------------------------------------------------------------------

1.To start the game, type 'p' and press Enter. To exit the game, just type 'e' and press Enter.
2.Then Select the game difficulty level
	To select Easy mode, type 'e' and press Enter
	To select Medium mode, type 'm' and press Enter
	To select Hard mode, type 'h' and press Enter

Now you are going to play cricket with the computer.

3.Then enter Your team name
	Type your team name and press Enter
4.Then enter computer's team name
	Type a name and press Enter. You cannot enter your team name for computer's team name! If needed just try ;)  

Now you are ready to start playing. Then game will check how lucky you are by flipping the coin.
The team which win the toss will bat first.

5.Type 'p' and press Enter to play the game!

At the end of the match, score board will be displayed.

Enjoy!

Rules of the game are as follows:
---------------------------------

1.Two teams, 6 players per team
2.Everyone can ball and bat
3.Runs can be 0, 1, 2, 3, 4, 6
4.Two ways to get out - caught and bowled
5.Three balls per over, 5 overs per team
6.Batting team is decided by a toss
7.The first team to bat will be batting until all-out or overs finish
8.The winning team will be the one with the highest score of the two


	